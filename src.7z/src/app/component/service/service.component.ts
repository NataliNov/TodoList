import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Item, typeItem } from './type'
import { switchMap } from 'rxjs';


@Injectable()
export class HttpService {

    errorMessage = '';

    constructor(private http: HttpClient) { }

    /**
     * Возвращает записи
     * @param {string[]} type признак вовзращения типа записей. При отсутствии выводит все записи 
     * @returns 
     */
    getAllItems(type?: string) {
        let params = {};
        if (type) {
            params = type === typeItem.active ?
                new HttpParams().set('type', typeItem.active) :
                new HttpParams().set('type', typeItem.completed);
        }

        return this.http.get('http://localhost:4200/getAllItems', { params });
    }

    addItem(item: Item) {
        return this.http.post('http://localhost:4200/addItem', item).pipe(
            switchMap(() => this.getAllItems())
        );
    }

    /**
     * Удаление записи/ записей
     * Если не передан параметр - то удаляем все записи с флагом выполнен
     * @param {Item} item удаляемая запись 
     * @returns 
     */
    removeItem(item?: Item) {
        let params;
        if (!item) {
            params = new HttpParams()
                .set('type', typeItem.completed)
        };

        return this.http.delete('http://localhost:4200/removeItem', (item ? { body: item } : { params })).pipe(
            switchMap(() => this.getAllItems())
        );
    }

    updateItem(item: Item) {
        return this.http.put('http://localhost:4200/updateItem', item).pipe(
            switchMap(() => this.getAllItems())
        );
    }

    selectedAllItems(isSelect: boolean) {
        const params = new HttpParams()
            .set('selectedAllItems', isSelect);
        return this.http.put('http://localhost:4200/selectItems', null, { params }).pipe(
            switchMap(() => this.getAllItems())
        );
    }
}