import { ChangeDetectionStrategy, Component } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Subject, take, takeUntil, tap } from 'rxjs';
import { HttpService } from './service/service.component';
import { Item, ItemsData, typeItem } from './service/type'
import { createForm } from '../binding/addForm'

@Component({
    selector: 'app-service-component',
    templateUrl: './todoList.component.html',
    styleUrls: ['../app.component.css'],
    providers: [HttpService],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ServiceListComponent {
    items: FormGroup[] = [];
    isSelectAll = false;
    count = 0; // количество всех записей нужно для вывода кнопки Очистить завершенные
    countActive = 0; //количество активных
    addForm = createForm();
    readOnlyInput = true;
    activeFilter = ''; // признак активности кнопки фильтра. Три состояния - '', active и completed
    private destroy$: Subject<void> = new Subject();

    constructor(public httpService: HttpService) { }

    ngOnInit() {
        this.httpService.getAllItems().pipe(
            take(1),
            tap((items: any) => {
                this.readData(items);
            }),
            takeUntil(this.destroy$)
        ).subscribe()
    }

    ngOnDestroy() {
        this.destroy$.next();
        this.destroy$.complete();
    }

    readData(data: ItemsData) {
        const items: FormGroup[] = [];
        data.items.forEach((item: Item) => {
            items.push(createForm(item));
        });
        this.items = items;
        this.countActive = data.countActive;
        this.count = data.count;
    }

    onSelectAll() {
        this.httpService.selectedAllItems(this.isSelectAll)
            .pipe(
                take(1),
                tap((items: any) => {
                    this.readData(items);
                }),
                takeUntil(this.destroy$)
            )
            .subscribe();
    }

    addItem() {
        if (this.addForm.valid) {
            this.httpService.addItem({
                name: this.addForm.get("name")?.value,
                checked: false,
            })
                .pipe(
                    take(1),
                    tap((items: any) => {
                        this.readData(items);
                    }),
                    takeUntil(this.destroy$)
                )
                .subscribe();
            this.addForm.patchValue({ name: "" });
            this.isSelectAll = false;
            this.readOnlyInput = true;
        }
    }

    removeItem(item: Item) {
        this.httpService.removeItem(item)
            .pipe(
                take(1),
                tap((items: any) => {
                    this.readData(items);
                }),
                takeUntil(this.destroy$)
            )
            .subscribe();
    }

    onChangedCheked(item: Item) {
        this.isSelectAll = false;
        this.setChangedItem(item);
    }

    setChangedItem(item: Item) {
        this.httpService.updateItem(item)
            .pipe(
                take(1),
                tap((items: any) => {
                    this.readData(items);
                }),
                takeUntil(this.destroy$)
            )
            .subscribe();
    }

    onCheckItem(item: Item) {
        this.count = item.checked ? this.count-- : this.count++;
    }

    showAll() {
        this.httpService.getAllItems()
            .pipe(
                take(1),
                tap((items: any) => {
                    this.readData(items);
                }),
                takeUntil(this.destroy$)
            )
            .subscribe();
        this.activeFilter = '';
    }

    showActive() {
        this.httpService.getAllItems(typeItem.active)
            .pipe(
                take(1),
                tap((items: any) => {
                    this.readData(items);
                }),
                takeUntil(this.destroy$)
            )
            .subscribe();
        this.activeFilter = typeItem.active;
    }

    showCompleted() {
        this.httpService.getAllItems(typeItem.completed)
            .pipe(
                take(1),
                tap((items: any) => {
                    this.readData(items);
                }),
                takeUntil(this.destroy$)
            )
            .subscribe();
        this.activeFilter = typeItem.completed;
    }

    clearCompleted() {
        this.httpService.removeItem()
            .pipe(
                take(1),
                tap((items: any) => {
                    this.readData(items);
                }),
                takeUntil(this.destroy$)
            )
            .subscribe();
    }
}
