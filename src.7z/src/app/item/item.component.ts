import { ChangeDetectionStrategy, Component, EventEmitter, HostBinding, HostListener, Input, Output} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Item } from '../component/service/type';

@Component({
    selector: 'app-item-component',
    templateUrl: './item.component.html',
    styleUrls: ['./item.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush
})

export class ItemComponent {
    @Input() item: FormGroup = new FormGroup({});

    @Output() onDelete = new EventEmitter<Item>();
    deleted() {
        this.onDelete.emit(this.item.getRawValue());
    }
    @Output() onChecked = new EventEmitter<Item>();
    checked() {
        this.onChecked.emit(this.item.getRawValue());
    }
    @Output() onChanged = new EventEmitter<Item>();
    @Output() onEdit = new EventEmitter<Item>();
    changed() {
        if (!this.isReadOnlyInput) {
            this.isReadOnlyInput = true;
            this.onChanged.emit(this.item.getRawValue());
        }
    }

    isReadOnlyInput = true;
    @HostBinding('attr.tabIndex') tabindex = 0;

    @HostListener('blur')
    blur() {
        this.isReadOnlyInput = true;
    }

    onDblClick() {
        this.isReadOnlyInput = !this.isReadOnlyInput;
        this.onEdit.emit(this.item.getRawValue());
    }
}

