import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { ItemComponent } from './item/item.component';
import { ServiceListComponent } from './component/todoList.component'
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { BackendInterceptor } from './intercepter';

@NgModule({
    declarations: [
        AppComponent,
        ItemComponent,
        ServiceListComponent
    ],
    imports: [
        BrowserModule,
        ReactiveFormsModule,
        FormsModule,
        HttpClientModule,
    ],
    providers: [
        {
             provide: HTTP_INTERCEPTORS,
             useClass: BackendInterceptor,
             multi: true,
        }],
    bootstrap: [AppComponent]
})
export class AppModule { }
